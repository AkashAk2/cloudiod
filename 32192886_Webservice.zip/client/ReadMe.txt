# Cloudiod_client.py

Cloudiod_client  is a Python script to invoke your web service endpoint according to the Assignment 1 specification

## Installation

All the required packages are part of the basic python installation. Please use python 3.5 or higher.

## Usage format

python Cloudiod_client.py  <input folder name> <URL> <num_threads>

## Sample run command

python Cloudiod_client.py  inputfolder/  http://localhost:5000/api/object_detection 4